<?php
if (!defined('ABSPATH')) {
    exit;
}

class WC_Banorte_Payworks_API {
    private $merchant_id;
    private $terminal_id;
    private $user_id;
    private $password;
    private $test_mode;
    private $api_endpoint;
    private $logger;

    public function __construct($merchant_id, $terminal_id, $user_id, $password, $test_mode = false) {
        $this->merchant_id = $merchant_id;
        $this->terminal_id = $terminal_id;
        $this->user_id = $user_id;
        $this->password = $password;
        $this->test_mode = $test_mode;
        $this->api_endpoint = $test_mode ? 'https://sandboxws.smartdt.com.mx/api/v1/payworks' : 'https://via.banorte.com/payw2/jwt';
        $this->logger = new WC_Banorte_Payworks_Logger();
    }

    /**
     * Procesa un pago con tarjeta
     * 
     * @param array $card_data Datos de la tarjeta
     * @param float $amount Monto a cobrar
     * @param string $order_id ID de la orden
     * @param string $currency Moneda (MXN por defecto)
     * @return array Respuesta del proceso
     */
    public function process_payment($card_data, $amount, $order_id, $currency = 'MXN') {
        $endpoint = $this->api_endpoint;
        
        // Formatear el monto (debe tener 2 decimales)
        $amount = number_format($amount, 2, '.', '');
        
        // Preparar los datos para la transacción
        $transaction_data = array(
            'merchant_id' => $this->merchant_id,
            'terminal_id' => $this->terminal_id,
            'user' => $this->user_id,
            'password' => $this->password,
            'command' => 'AUTH',
            'amount' => $amount,
            'mode' => 'PRD',
            'reference' => $order_id,
            'currency' => 'MXN',
            'card_number' => str_replace(' ', '', $card_data['number']),
            'card_expiration' => str_replace(' / ', '', $card_data['expiry']),
            'security_code' => $card_data['cvv'],
            'entry_mode' => 'MANUAL',
            'response_language' => 'ES'
        );

        $this->logger->info(sprintf('Iniciando proceso de pago para orden #%s', $order_id));
        
        try {
            // Realizar la petición a la API
            $response = $this->make_request($endpoint, $transaction_data, $order_id);
            $this->logger->log_transaction($order_id, 'payment', $response);
            
            if (isset($response['response_code']) && $response['response_code'] === '00') {
                return array(
                    'success' => true,
                    'transaction_id' => $response['folio'],
                    'auth_code' => $response['authorization']
                );
            } else {
                $error_message = isset($response['response_text']) ? $response['response_text'] : 'Error desconocido';
                throw new Exception($error_message);
            }
        } catch (Exception $e) {
            $this->logger->error(sprintf('Error en proceso de pago para orden #%s: %s', $order_id, $e->getMessage()));
            throw $e;
        }
    }

    /**
     * Realiza un reembolso
     * 
     * @param string $transaction_id ID de la transacción original
     * @param float $amount Monto a reembolsar
     * @param string $order_id ID de la orden
     * @return array Respuesta del proceso
     */
    public function process_refund($transaction_id, $amount, $order_id) {
        $endpoint = $this->api_endpoint . '/PaymentWS/Payment';
        
        $amount = number_format($amount, 2, '.', '');
        
        $refund_data = array(
            'merchant_id' => $this->merchant_id,
            'terminal_id' => $this->terminal_id,
            'user' => $this->user_id,
            'password' => $this->password,
            'cmd_trans' => 'REVERSAL',  
            'amount' => $amount,
            'mode' => 'RND',
            'customer_ref' => $order_id,
            'reference' => $transaction_id
        );

        $this->logger->info(sprintf('Iniciando reembolso para orden #%s', $order_id));
        
        try {
            $response = $this->make_request($endpoint, $refund_data, $order_id);
            $this->logger->log_transaction($order_id, 'refund', $response);
            
            return $this->process_response($response);
        } catch (Exception $e) {
            $this->logger->error(sprintf('Error en reembolso para orden #%s: %s', $order_id, $e->getMessage()));
            throw $e;
        }
    }

    /**
     * Realiza la petición HTTP a la API de Banorte
     */
    private function make_request($endpoint, $data, $order_id = '') {
        $args = array(
            'method' => 'POST',
            'body' => http_build_query($data),
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json',
                'Cache-Control' => 'no-cache'
            ),
            'timeout' => 60,
            'sslverify' => true,
            'user-agent' => 'WordPress/' . get_bloginfo('version') . '; ' . get_bloginfo('url')
        );

        // Log de la petición (enmascarando datos sensibles)
        $log_data = $data;
        if (isset($log_data['CARD_NUMBER'])) {
            $log_data['CARD_NUMBER'] = 'XXXX' . substr($log_data['CARD_NUMBER'], -4);
        }
        if (isset($log_data['SECURITY_CODE'])) {
            $log_data['SECURITY_CODE'] = 'XXX';
        }
        if (isset($log_data['PASSWORD'])) {
            $log_data['PASSWORD'] = 'XXXXX';
        }
        
        $this->logger->info(sprintf('Request a %s: %s', $endpoint, json_encode($log_data)));

        $response = wp_remote_post($endpoint, $args);
        $http_code = wp_remote_retrieve_response_code($response);
        
        $this->logger->info(sprintf('HTTP Response Code: %s', $http_code));

        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            $this->logger->error(sprintf('Error en la petición: %s', $error_message));
            throw new Exception($error_message);
        }

        $body = wp_remote_retrieve_body($response);
        
        // Log de la respuesta raw
        $this->logger->info(sprintf('Respuesta raw: %s', $body));

        if (empty($body)) {
            $headers = wp_remote_retrieve_headers($response);
            $this->logger->error(sprintf('Headers de respuesta: %s', json_encode($headers)));
            throw new Exception('La respuesta del servidor está vacía');
        }

        // Intentar decodificar como JSON
        $decoded_response = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            // Si no es JSON, intentar parsear la respuesta como query string
            parse_str($body, $decoded_response);
            if (empty($decoded_response)) {
                $this->logger->error(sprintf('Error decodificando respuesta: %s', $body));
                throw new Exception('Error decodificando la respuesta del servidor');
            }
        }

        $this->logger->info(sprintf('Respuesta procesada: %s', json_encode($decoded_response)));

        return $decoded_response;
    }

    /**
     * Procesa la respuesta de la API
     */
    private function process_response($response) {
        if (empty($response)) {
            return array(
                'success' => false,
                'error_message' => __('No se recibió respuesta del servidor de Banorte', 'wc-banorte-payworks')
            );
        }

        // Códigos de respuesta exitosos de Banorte
        $success_codes = array('A01', 'A02', 'A03', 'A04', 'A05');

        if (isset($response['response_code']) && in_array($response['response_code'], $success_codes)) {
            return array(
                'success' => true,
                'transaction_id' => $response['folio'],
                'auth_code' => $response['auth_code'],
                'message' => $response['response_msg']
            );
        }

        return array(
            'success' => false,
            'error_code' => $response['response_code'],
            'error_message' => $response['response_msg']
        );
    }
}